import React from 'react';
import './SelectYourMeal.css'
import MealItemList from '../mealitemlist/MealItemList'

class SelectYourMeal extends React.Component {
    
    render() {
        return (
            <div className="pageContainer">
                <MealItemList
                    heading={'Select your breakfast'}
                    items={['Poha', 'Bread', 'Chips']}
                />

                <MealItemList
                    heading={'Select your lunch'}
                    items={['Rice', 'Dal', 'Curry']}
                />
            </div>
        )
    }
}

export default SelectYourMeal