import React, { Fragment } from 'react'
import './MealItemList.css'

class MealItemList extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            sign: '+'
        }
    }

    componentDidMount() {
        this.meal.style.display = 'none'
    }

    toggleFoodList = () => {
        const { sign } = this.state
        if (sign === '+') {
            this.meal.style.display = 'block'
            this.setState({
                sign: '-'
            })
        } else {
            this.meal.style.display = 'none'
            this.setState({
                sign: '+'
            })
        }
    }

    render() {
        const { heading, items } = this.props
        const { sign } = this.state
        return(
            <Fragment>
                <div className='menuContainer' onClick={this.toggleFoodList}>
                    <div className="heading">{heading}</div>
                    <div className="icon">{sign}</div>
                </div>
                <div className="foodList" ref = {el => { this.meal = el }}>
                    <ul>
                        {
                            items.map((item, i) => <li key={i}>{item}</li>)
                        }
                    </ul>
                </div>
            </Fragment>
        )
    }
}

export default MealItemList