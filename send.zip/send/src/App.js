import React from 'react';
import SelectYourMeal from './components/selectyourmeal/SelectYourMeal'
import './App.css';

function App() {
  return (
    <div className="App">
      <SelectYourMeal/>
    </div>
  );
}

export default App;
